from fastapi import APIRouter, Depends, HTTPException
from app.config import dynamodb
from app.controllers.user_controller import get_all_users_controller
from app.controllers.auth_decorators import auth_required

users_db = dynamodb.Table("Users")
users_routes = APIRouter(prefix="/users",tags=["users"])

@users_routes.get("/")
async def get_users(user_session: dict = Depends(auth_required())):
    """
    Obtener todos los usuarios si el rol es ADMIN,
    de lo contrario devuelve solo la información del usuario autenticado
    """
    user_response = users_db.get_item(Key={"id": user_session["id"]})

    if not user_response.get("Item"):
        raise HTTPException(status_code=404, detail="Usuario no encontrado")

    if user_session["role"].lower() == "admin":
        return await get_all_users_controller()
    else:
        return await get_all_users_controller(user_session["id"])