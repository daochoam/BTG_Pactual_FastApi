from fastapi import APIRouter, Depends, Path
from app.controllers.auth_decorators import auth_required
from app.controllers.user_bank_funds_controller import (
    create_user_bank_fund_controller,
    get_user_bank_funds_controller,
    delete_user_bank_fund_controller
)

user_bank_funds_routes = APIRouter(prefix="/user-bank-funds",tags=["user_bank_funds"])

# CREATE
@user_bank_funds_routes.post("/{bank_funds_id}", summary="Asociar un fondo bancario a un usuario")
def create_user_bank_fund(
    bank_funds_id: str = Path(..., description="ID del fondo bancario"),
    user_session: dict = Depends(auth_required())
):
    return create_user_bank_fund_controller(user_session, bank_funds_id)

# READ ALL
@user_bank_funds_routes.get("/", summary="Obtener todos los fondos bancarios de un usuario")
def list_user_bank_funds(
    user_session: dict = Depends(auth_required())
):
    return get_user_bank_funds_controller(user_session)

# READ ONE
@user_bank_funds_routes.get("/{id}", summary="Obtener un fondo bancario de un usuario por ID")
def get_user_bank_fund(
    id: str = Path(..., description="ID del fondo bancario"),
    user_session: dict = Depends(auth_required())
):
    return get_user_bank_funds_controller(user_session, id)

# DELETE
@user_bank_funds_routes.delete("/{user_bank_funds_id}", summary="Eliminar un fondo bancario asociado a un usuario")
def delete_user_bank_fund(
    user_bank_funds_id: str = Path(..., description="ID de la relación usuario-fondo bancario"),
    user_session: dict = Depends(auth_required())
):
    return delete_user_bank_fund_controller(user_session, user_bank_funds_id)
