from pydantic import BaseModel, Field
from typing import Literal

class RegisterUserModel(BaseModel):
    nit: str = Field(..., title="NIT del usuario", example="123456789")
    name: str = Field(..., title="Nombre", example="Daniel")
    last_name: str = Field(..., title="Apellido", example="8A")
    email: str = Field(..., title="Correo electrónico", example="daniel@example.com")
    phone: str = Field(..., title="Teléfono", example="+573001234567")
    role: Literal['USER', 'ADMIN'] = Field(..., title="Rol del usuario", example="USER")
    password: str = Field(..., title="Contraseña", example="MiContraseñaSegura123")


class LoginUserModel(BaseModel):
    email: str = Field(..., title="Correo electrónico", example="daniel@example.com")
    password: str = Field(..., title="Contraseña", example="MiContraseñaSegura123")
