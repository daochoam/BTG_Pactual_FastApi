from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class UserBankFundAuditModel(BaseModel):
    id: Optional[str] = Field(None, title="ID del registro de auditoría")
    user_id: Optional[str] = Field(None, title="ID del usuario")
    bank_funds_id: Optional[str] = Field(None, title="ID del fondo bancario asociado")
    action: Optional[str] = Field(None, title="Acción realizada", example="CREATED")
    timestamp: Optional[datetime] = Field(None, title="Fecha y hora del evento", example="2025-08-22T20:00:00Z")
