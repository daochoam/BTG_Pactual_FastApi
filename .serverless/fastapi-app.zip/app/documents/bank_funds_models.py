from pydantic import BaseModel, Field
from typing import Optional

class CreateBankFundsModel(BaseModel):
    name: str = Field(..., title="Nombre del fondo")
    category_ids: str = Field(..., title="Categoría del fondo")
    min_amount: float = Field(..., title="Monto mínimo")
    currency: Optional[str] = Field(None, title="Moneda", example="USD")

class UpdateBankFundsModel(BaseModel):
    name: Optional[str] = Field(None, title="Nuevo nombre")
    category_ids: Optional[str] = Field(None, title="Nuevas categorías")
    min_amount: Optional[float] = Field(None, title="Nuevo monto mínimo")
    currency: Optional[str] = Field(None, title="Nueva moneda", example="USD")
