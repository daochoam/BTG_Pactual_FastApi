from pydantic import BaseModel, Field
from typing import Optional

class CreateCategoryModel(BaseModel):
    name: str = Field(..., title="Nombre de la categoría", example="Inversiones")
    description: Optional[str] = Field(None, title="Descripción de la categoría", example="Fondos de inversión a largo plazo")

class UpdateCategoryModel(BaseModel):
    name: Optional[str] = Field(None, title="Nuevo nombre")
    description: Optional[str] = Field(None, title="Nueva descripción")
