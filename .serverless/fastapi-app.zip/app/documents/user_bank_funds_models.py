from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class UserBankFundModel(BaseModel):
    id: Optional[str] = Field(None, title="ID de la relación usuario-fondo")
    user_id: Optional[str] = Field(None, title="ID del usuario")
    bank_funds_id: Optional[str] = Field(None, title="ID del fondo bancario")
    created_at: Optional[datetime] = Field(None, title="Fecha de creación", example="2025-08-22T20:00:00Z")
