from app.schemas.user_bank_funds_audit import user_bank_funds_audit_db

# READ
def get_user_bank_funds_audit_controller(user_session, user_bank_funds_audit_id=None):
    if user_bank_funds_audit_id:
        response = user_bank_funds_audit_db.get_item(Key={"id": user_bank_funds_audit_id})
        return response.get("Item"), 200

    # Buscar todos los items de un usuario con scan
    response = user_bank_funds_audit_db.scan(
        FilterExpression="user_id = :uid",
        ExpressionAttributeValues={":uid": user_session['user_id']},
    )
    items = response.get("Items", [])
    # Ordenar en Python por created_at descendente
    items.sort(key=lambda x: x.get("created_at", ""), reverse=True)

    return {"items": items, "status": 200}
