from app.schemas.users import users_db

def get_all_users_controller(user_id=None):
    """Obtener todos los usuarios (solo admin)"""
    response = users_db.scan()
    items = response.get("Items", [])
    if user_id:
        items = [item for item in items if item.get("id") == user_id]
        if not items:
            return {"error": "User not found"}, 404
    return items, 200


def update_user_controller(user_id, data):
    """Actualizar un usuario por id"""
    resp = users_db.get_item(Key={"id": user_id})
    user = resp.get("Item")
    if not user:
        return {"error": "User not found"}, 404

    # Solo actualizar si hay campos válidos
    valid_fields = ["amount", "name"]
    update_expressions = []
    expression_values = {}

    for field in valid_fields:
        if field in data:
            user[field] = data[field]
            update_expressions.append(f"{field} = :{field[0]}")
            expression_values[f":{field[0]}"] = data[field]

    if not update_expressions:
        return {"error": "No valid fields to update"}, 400

    update_expr = "set " + ", ".join(update_expressions)
    users_db.update_item(
        Key={"id": user_id},
        UpdateExpression=update_expr,
        ExpressionAttributeValues=expression_values,
    )

    return user, 200
