from decimal import Decimal
from app.schemas.users import users_db
from app.schemas.bank_funds import bank_funds_db
from app.schemas.user_bank_funds import UserBankFundsSchema, user_bank_funds_db
from app.schemas.user_bank_funds_audit import UserBankFundsAuditSchema, user_bank_funds_audit_db
from app.utils.send_email import send_retired_funds_email, send_subscription_funds_email
from app.utils.time import get_current_time


# CREATE
def create_user_bank_fund_controller(user_session, bank_funds_id):
    # Buscar el usuario en la tabla de usuarios
    user_response = users_db.get_item(Key={"id": user_session['user_id']})
    user = user_response.get("Item")
    if not user:
        return {"error": "User not found"}, 404

    # Verificar que el BankFund existe
    bf_response = bank_funds_db.get_item(Key={"id": bank_funds_id})
    bank_fund = bf_response.get("Item")
    if not bank_fund:
        return {"error": "BankFund not found"}, 404

    # Validar saldo disponible
    user_amount = Decimal(user.get("amount", "0"))
    min_amount = Decimal(bank_fund["min_amount"])

    if user_amount < min_amount:
        return {"error": f"No tiene saldo disponible para vincularse al fondo {bank_fund['name']}"}, 400

    # Actualizar saldo del usuario
    new_amount = user_amount - min_amount
    users_db.update_item(
        Key={"id": user['id']},
        UpdateExpression="SET amount = :a, updated_at = :u",
        ExpressionAttributeValues={
            ":a": new_amount,
            ":u": get_current_time()
        }
    )

    # Crear relación user-bankfund y su auditoría
    user_bank_funds = UserBankFundsSchema(
        user_id=user['id'],
        bank_fund_id=bank_funds_id,
        amount=min_amount,
        currency=bank_fund["currency"],
        status='OPEN'
    )
    user_bank_funds_audit = UserBankFundsAuditSchema(parent=user_bank_funds)

    user_bank_funds_db.put_item(Item=user_bank_funds.to_dict())
    user_bank_funds_audit_db.put_item(Item=user_bank_funds_audit.to_dict())

    # Enviar correo de confirmación
    send_subscription_funds_email(
        to_email=user.get("email"),
        user_name=user.get("name"),
        bank_fund=bank_fund
    )

    return {'item': user_bank_funds.to_dict(), 'status': 201}

# READ
def get_user_bank_funds_controller(user_session, id=None):
    if id:
        response = user_bank_funds_db.get_item(Key={"id": id})
        return {'item': response.get("Item")}, 200

    # Buscar todos los items de un usuario con scan
    response = user_bank_funds_db.scan(
        FilterExpression="user_id = :uid",
        ExpressionAttributeValues={":uid": user_session['user_id']},
    )
    items = response.get("Items", [])
    # Ordenar en Python por created_at descendente
    items.sort(key=lambda x: x.get("created_at", ""), reverse=True)

    return {'items': items}, 200

# DELETE
def delete_user_bank_fund_controller(user_session, user_bank_funds_id):
    # Verificar que el UserBankFund existe
    response = user_bank_funds_db.get_item(Key={"id": user_bank_funds_id})
    user_bank_fund = response.get("Item")
    if not user_bank_fund:
        return {"error": "UserBankFund not found"}, 404

    # Verificar que el BankFund existe
    response = bank_funds_db.get_item(Key={"id": user_bank_fund.get("bank_funds_id")})
    bank_fund = response.get("Item")
    if not bank_fund:
        return {"error": "BankFund not found"}, 404

    # Buscar el usuario en la tabla de usuarios
    user_response = users_db.get_item(Key={"id": user_session['user_id']})
    user = user_response.get("Item")
    if not user:
        return {"error": "User not found"}, 404

    # Actualizar saldo del usuario
    user_amount = Decimal(user.get("amount", "0"))
    refund_amount = Decimal(bank_fund["min_amount"])
    new_amount = user_amount + refund_amount

    users_db.update_item(
        Key={"id": user['id']},
        UpdateExpression="SET amount = :a, updated_at = :u",
        ExpressionAttributeValues={
            ":a": new_amount,
            ":u": get_current_time()
        }
    )

    # Actualizar estado del UserBankFund
    updated_at = get_current_time()
    user_bank_funds_db.update_item(
        Key={"id": user_bank_funds_id},
        UpdateExpression="SET #s = :s, updated_at = :u",
        ExpressionAttributeNames={
            "#s": "status"
        },
        ExpressionAttributeValues={
            ":s": "CLOSED",
            ":u": updated_at
        }
    )

    # Obtener el UserBankFund actualizado
    updated_response = user_bank_funds_db.get_item(Key={"id": user_bank_funds_id})
    updated_user_bank_fund = updated_response.get("Item")

    # Registrar en auditoría
    user_bank_funds_schema = UserBankFundsSchema.from_dict(updated_user_bank_fund)
    user_bank_fund_audit = UserBankFundsAuditSchema(parent=user_bank_funds_schema)
    user_bank_funds_audit_db.put_item(Item=user_bank_fund_audit.to_dict())

    # Enviar correo de confirmación
    send_retired_funds_email(
        to_email=user.get("email"),
        user_name=user.get("name"),
        bank_fund=bank_fund
    )

    return {"item": user_bank_funds_schema.to_dict(), "status": 200}
