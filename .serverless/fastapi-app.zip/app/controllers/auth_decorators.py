# app/controllers/auth_decorators.py
import inspect
from fastapi import Request, HTTPException, Depends
from fastapi.responses import JSONResponse
from app.config import Config, cognito_client

def validate_tokens(access_header, refresh_token):
    if not access_header or not access_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Token requerido")
    if not refresh_token:
        raise HTTPException(status_code=401, detail="Refresh token requerido")

    access_token = access_header.split(" ")[1]

    try:
        user_info = cognito_client.get_user(AccessToken=access_token)
        attributes = {attr["Name"]: attr["Value"] for attr in user_info["UserAttributes"]}
    except cognito_client.exceptions.NotAuthorizedException:
        try:
            response = cognito_client.initiate_auth(
                ClientId=Config.AWS_COGNITO_CLIENT_ID,
                AuthFlow="REFRESH_TOKEN_AUTH",
                AuthParameters={"REFRESH_TOKEN": refresh_token}
            )
            access_token = response["AuthenticationResult"]["AccessToken"]
            refresh_token = response["AuthenticationResult"].get("RefreshToken", refresh_token)
            user_info = cognito_client.get_user(AccessToken=access_token)
            attributes = {attr["Name"]: attr["Value"] for attr in user_info["UserAttributes"]}
        except Exception as e:
            raise HTTPException(status_code=401, detail=f"Token inválido o refresh token expirado: {str(e)}")

    payload = {
        "user_id": attributes.get("sub"),
        "role": attributes.get("custom:role"),
    }
    return payload

def get_auth_payload(request: Request):
    access_header = request.headers.get("Authorization")
    refresh_token = request.headers.get("X-Refresh-Token")
    return validate_tokens(access_header, refresh_token)

def auth_required(require_admin: bool = False):
    def dependency(request: Request):
        payload = get_auth_payload(request)
        if require_admin and payload.get("role", "").lower() != "admin":
            raise HTTPException(status_code=403, detail="Acceso denegado")
        return payload
    return dependency

# Ejemplo de uso en un endpoint FastAPI:
# from fastapi import APIRouter
# router = APIRouter()
#
# @router.get("/admin")
# async def admin_endpoint(payload_access_refresh=auth_required(require_admin=True)):
#     payload, access_token, refresh_token = payload_access_refresh
#     response = {"message": "Acceso concedido", "user_id": payload["user_id"]}
#     headers = {
#         "Authorization": f"Bearer {access_token}",
#         "X-Refresh-Token": refresh_token
#     }
#     return JSONResponse(content=response, headers=headers)
