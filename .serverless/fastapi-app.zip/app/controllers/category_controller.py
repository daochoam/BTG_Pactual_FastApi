from app.schemas.category import CategorySchema, categories_db
from app.utils.time import get_current_time

# CREATE
def create_category_controller(user_id, data):
    if not data.get("name"):
        return {"error": "Name is required"}, 400

    category = CategorySchema(user_id, data.get("name"), data.get("description"))
    categories_db.put_item(Item=category.to_dict())
    return {"item": category.to_dict(), "status": 201}

# READ
def get_categories_controller(id=None):
    response = categories_db.scan()
    items = response.get("Items", [])
    if id:
        items = [item for item in items if item.get("id") == id]
        if not items:
            return {"error": "Category not found"}, 404

    return {"items": items, "status": 200}

def update_category_controller(user_id, id, data):
    update_expr = []
    expr_values = {}

    if "name" in data:
        update_expr.append("name = :n")
        expr_values[":n"] = data["name"]

    if "description" in data:
        update_expr.append("description = :d")
        expr_values[":d"] = data["description"]

    if not update_expr:
        return {"error": "Nothing to update"}, 400

    # Siempre actualizar user_updated_id y update_date
    update_expr.append("user_updated_id = :u")
    expr_values[":u"] = user_id
    update_expr.append("updated_at = :t")
    expr_values[":t"] = get_current_time()

    response = categories_db.update_item(
        Key={"id": id},
        UpdateExpression="SET " + ", ".join(update_expr),
        ExpressionAttributeValues=expr_values,
        ReturnValues="ALL_NEW"
    )

    return {"item": response.get("Attributes"), "status": 200}