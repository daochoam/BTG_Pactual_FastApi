from fastapi import APIRouter, HTTPException, Request, status, Header
from fastapi.responses import JSONResponse
from app.config import Config, cognito_client
from app.documents.auth_models import LoginUserModel
from app.schemas.users import UserSchema, users_db
from app.utils.secret_hash import get_secret_hash


def register_user(data: dict):
    required_fields = ["nit", "name", "last_name", "email", "phone", "password"]
    if not all(field in data and data[field] for field in required_fields):
        raise HTTPException(status_code=400, detail=f"{', '.join(required_fields)} fields are required")

    if users_db.scan(FilterExpression="nit = :n", ExpressionAttributeValues={":n": data["nit"]}).get("Items"):
        raise HTTPException(status_code=400, detail="NIT already registered")

    try:
        response = cognito_client.sign_up(
            ClientId=Config.AWS_COGNITO_CLIENT_ID,
            Username=data["email"],
            Password=data["password"],
            SecretHash=get_secret_hash(data["email"]),
            UserAttributes=[
                {"Name": "email", "Value": data["email"]},
                {"Name": "phone_number", "Value": data["phone"]},
                {"Name": "name", "Value": data["name"]},
                {"Name": "family_name", "Value": data["last_name"]},
                {"Name": "custom:role", "Value": data.get("role", UserSchema.RoleEnum.USER)},
            ]
        )
    except cognito_client.exceptions.UsernameExistsException:
        raise HTTPException(status_code=400, detail="Email already registered")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    user = UserSchema(
        **{k: data.get(k) for k in ["nit","name","last_name","email", "phone","role","amount","currency"]},
        id=response["UserSub"]
    )
    users_db.put_item(Item=user.to_dict())

    return {"message": "User registered, check your email to confirm", "user_id": response["UserSub"]}

def login_user(data: LoginUserModel):
    try:
        response = cognito_client.initiate_auth(
            ClientId=Config.AWS_COGNITO_CLIENT_ID,
            AuthFlow="USER_PASSWORD_AUTH",
            AuthParameters={
                "USERNAME": data.email,
                "PASSWORD": data.password,
                "SECRET_HASH": get_secret_hash(data.email)
            },
        )

        access_token = response["AuthenticationResult"]["AccessToken"]
        refresh_token = response["AuthenticationResult"]["RefreshToken"]

        user_info = cognito_client.get_user(AccessToken=access_token)
        attributes = {attr["Name"]: attr["Value"] for attr in user_info["UserAttributes"]}

        body = {
            "id": attributes.get("sub"),
            "role": attributes.get("custom:role"),
        }

        headers = {
            "Authorization": f"Bearer {access_token}",
            "X-Refresh-Token": refresh_token
        }
        return JSONResponse(content=body, headers=headers, status_code=200)

    except cognito_client.exceptions.NotAuthorizedException:
        raise HTTPException(status_code=401, detail="Incorrect username or password")
    except cognito_client.exceptions.UserNotConfirmedException:
        raise HTTPException(status_code=401, detail="User not verified")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

def logout_user(authorization: str, refresh_token: str):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing access token")
    if not refresh_token:
        raise HTTPException(status_code=401, detail="Missing refresh token")

    access_token = authorization.split(" ")[1]

    try:
        cognito_client.revoke_token(
            Token=refresh_token,
            ClientId=Config.AWS_COGNITO_CLIENT_ID,
            ClientSecret=Config.AWS_COGNITO_CLIENT_SECRET
        )
        return {"message": "Logout successful"}
    except Exception as e:
        try:
            cognito_client.global_sign_out(AccessToken=access_token)
        except Exception:
            pass
        raise HTTPException(status_code=400, detail=str(e))

def get_current_user(user_id: str):
    resp = users_db.get_item(Key={"id": user_id})
    user = resp.get("Item")
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    user.pop("password", None)
    return user
