from app.config import dynamodb_client
from boto3.dynamodb.types import TypeDeserializer
from app.schemas.category import categories_db
from app.schemas.bank_funds import BankFundsSchema, bank_funds_db
from app.utils.time import get_current_time



serializer = TypeDeserializer()

def deserialize(item):
    """Convierte un item de DynamoDB a dict normal"""
    return {k: serializer.deserialize(v) for k, v in item.items()}

# CREATE
def create_bank_funds_controller(user_id, data):
    """Crea un nuevo fondo bancario."""
    cat_response = categories_db.get_item(Key={"id": data["category_id"]})
    if "Item" not in cat_response:
        return {"error": "Category does not exist"}, 400

    bankfund = BankFundsSchema(
        **{k: data.get(k) for k in ["name","category_id","min_amount","currency"]},
        user_created=user_id
    )
    
    bank_funds_db.put_item(Item=bankfund.to_dict())
    return {"item": bankfund.to_dict(), "status": 201}

def get_bank_funds_controller(id=None):
    response = bank_funds_db.scan()
    items = response.get("Items", [])
    if id:
        items = [item for item in items if item.get("id") == id]
        if not items:
            return {"error": "BankFund not found"}, 404

    # Obtener todos los category_ids únicos
    category_ids = list({item["category_id"] for item in items if "category_id" in item})

    if category_ids:
        keys = [{"id": {"S": cid}} for cid in category_ids]
        batch_response = dynamodb_client.batch_get_item(
            RequestItems={categories_db.name: {"Keys": keys}}
        )
        categories_raw = batch_response.get("Responses", {}).get(categories_db.name, [])
        categories = [deserialize(cat) for cat in categories_raw]
        cat_map = {cat["id"]: cat for cat in categories}

        for item in items:
            cat_id = item.get("category_id")
            if cat_id and cat_id in cat_map:
                item["category_id"] = cat_map[cat_id]

    return {"items": items, "status": 200}

# UPDATE
def update_bank_fund_controller(user_id, id, data):
    update_expr = []
    expr_values = {}

    # Campos editables
    if "name" in data:
        update_expr.append("name = :n")
        expr_values[":n"] = data["name"]

    if "category_id" in data:
        cat_response = categories_db.get_item(Key={"id": data["category_id"]})
        if "Item" not in cat_response:
            return {"error": "Category does not exist"}, 400
        update_expr.append("category_id = :c")
        expr_values[":c"] = data["category_id"]

    if "min_amount" in data:
        update_expr.append("min_amount = :m")
        expr_values[":m"] = data["min_amount"]

    if not update_expr:
        return {"error": "Nothing to update"}, 400

    # Auditoría: siempre actualizar user_updated y updated_at
    update_expr.append("user_updated = :u")
    expr_values[":u"] = user_id
    update_expr.append("updated_at = :t")
    expr_values[":t"] = get_current_time()

    # Ejecutar update en DynamoDB
    response = bank_funds_db.update_item(
        Key={"id": id},
        UpdateExpression="SET " + ", ".join(update_expr),
        ExpressionAttributeValues=expr_values,
        ReturnValues="ALL_NEW"
    )
    return {"item": response.get("Attributes"), "status": 200}

