# tests/category_controller_test.py
import pytest
from unittest.mock import patch, MagicMock
from app.controllers import category_controller as controller

USER_ID = "user-123"

# ------------------ CREATE ------------------
@patch("app.controllers.category_controller.categories_db.put_item")
def test_create_category_success(mock_put):
    data = {"name": "Test Category", "description": "Desc"}
    
    result, status = controller.create_category_controller(USER_ID, data)
    
    # Verificar status
    assert status == 201
    assert result["name"] == "Test Category"
    assert result["description"] == "Desc"
    assert result["user_created"] == USER_ID
    mock_put.assert_called_once()

def test_create_category_missing_name():
    data = {"description": "Desc"}
    
    result, status = controller.create_category_controller(USER_ID, data)
    
    assert status == 400
    assert "error" in result

# ------------------ READ ------------------
@patch("app.controllers.category_controller.categories_db.scan")
def test_get_categories_success(mock_scan):
    mock_scan.return_value = {
        "Items": [
            {"id": "cat-1", "name": "Cat 1", "description": "Desc 1"}
        ]
    }
    
    items, status = controller.get_categories_controller()
    
    assert status == 200
    assert len(items) == 1
    assert items[0]["id"] == "cat-1"

@patch("app.controllers.category_controller.categories_db.scan")
def test_get_category_by_id_not_found(mock_scan):
    mock_scan.return_value = {"Items": []}
    
    result, status = controller.get_categories_controller(id="non-existent")
    
    assert status == 404
    assert "error" in result

# ------------------ UPDATE ------------------
@patch("app.controllers.category_controller.categories_db.update_item")
@patch("app.controllers.category_controller.get_current_time", return_value="2025-08-22T15:00:00")
def test_update_category_success(mock_time, mock_update):
    mock_update.return_value = {
        "Attributes": {"id": "cat-1", "name": "Updated", "description": "Desc Updated"}
    }
    
    data = {"name": "Updated", "description": "Desc Updated"}
    result, status = controller.update_category_controller(USER_ID, "cat-1", data)
    
    assert status == 200
    assert result["name"] == "Updated"
    assert result["description"] == "Desc Updated"
    mock_update.assert_called_once()

def test_update_category_nothing_to_update():
    data = {}
    
    result, status = controller.update_category_controller(USER_ID, "cat-1", data)
    
    assert status == 400
    assert "error" in result
