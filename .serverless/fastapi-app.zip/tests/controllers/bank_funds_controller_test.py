import pytest
from unittest.mock import patch, MagicMock
from app.controllers import bank_funds_controller as controller

# -----------------------------
# Datos de ejemplo
# -----------------------------
user_id = "user-123"
bank_fund_data = {
    "name": "Fondo Prueba",
    "category_id": "cat-1",
    "min_amount": 1000,
    "currency": "COL"
}

# -----------------------------
# TEST CREATE
# -----------------------------
@patch("app.controllers.bank_funds_controller.bank_funds_db.put_item")
@patch("app.controllers.bank_funds_controller.categories_db.get_item")
def test_create_bank_fund_success(mock_get_cat, mock_put):
    # Mockear category existente
    mock_get_cat.return_value = {"Item": {"id": "cat-1", "name": "Categoria 1"}}
    mock_put.return_value = {}

    response, status = controller.create_bank_fund_controller(user_id, bank_fund_data)

    assert status == 201
    assert "id" in response
    assert response["message"] == "BankFund created"
    mock_put.assert_called_once()

@patch("app.controllers.bank_funds_controller.categories_db.get_item")
def test_create_bank_fund_missing_category(mock_get_cat):
    mock_get_cat.return_value = {}
    response, status = controller.create_bank_fund_controller(user_id, bank_fund_data)
    assert status == 400
    assert response["error"] == "Category does not exist"

# -----------------------------
# TEST GET
# -----------------------------
@patch("app.controllers.bank_funds_controller.bank_funds_db.scan")
@patch("app.controllers.bank_funds_controller.dynamodb_client.batch_get_item")
def test_get_bank_funds_success(mock_batch, mock_scan):
    mock_scan.return_value = {
        "Items": [
            {"id": "bf-1", "category_id": "cat-1", "name": "Fondo X", "min_amount": 1000}
        ]
    }

    # Mockear batch_get_item para categories
    mock_batch.return_value = {
        "Responses": {
            controller.categories_db.name: [
                {"id": {"S": "cat-1"}, "name": {"S": "Categoria 1"}}
            ]
        }
    }

    items, status = controller.get_bank_funds_controller()
    assert status == 200
    assert len(items) == 1
    assert isinstance(items[0]["category_id"], dict)
    assert items[0]["category_id"]["name"] == "Categoria 1"

# -----------------------------
# TEST UPDATE
# -----------------------------
@patch("app.controllers.bank_funds_controller.bank_funds_db.update_item")
@patch("app.controllers.bank_funds_controller.categories_db.get_item")
def test_update_bank_fund_success(mock_get_cat, mock_update):
    mock_get_cat.return_value = {"Item": {"id": "cat-1"}}
    mock_update.return_value = {"Attributes": {"id": "bf-1", "name": "Nuevo nombre"}}

    updated, status = controller.update_bank_fund_controller(user_id, "bf-1", {"name": "Nuevo nombre"})
    assert status == 200
    assert updated["name"] == "Nuevo nombre"
    mock_update.assert_called_once()

@patch("app.controllers.bank_funds_controller.categories_db.get_item")
def test_update_bank_fund_invalid_category(mock_get_cat):
    mock_get_cat.return_value = {}
    response, status = controller.update_bank_fund_controller(user_id, "bf-1", {"category_id": "cat-99"})
    assert status == 400
    assert response["error"] == "Category does not exist"

