# tests/user_bank_funds_audit_controller_test.py
import pytest
from unittest.mock import patch, MagicMock
from decimal import Decimal
from app.controllers import user_bank_funds_audit_controller as controller

@pytest.fixture
def mock_user():
    return {"id": "user-1", "amount": "1500"}

@pytest.fixture
def mock_bank_fund():
    return {"id": "bf-1", "name": "Fondo X", "min_amount": "1000"}

# ================= CREATE =================
@patch("app.controllers.user_bank_funds_audit_controller.users_db.get_item")
@patch("app.controllers.user_bank_funds_audit_controller.bank_funds_db.get_item")
@patch("app.controllers.user_bank_funds_audit_controller.users_db.update_item")
@patch("app.controllers.user_bank_funds_audit_controller.user_bank_funds_db.put_item")
@patch("app.controllers.user_bank_funds_audit_controller.user_bank_funds_audit_db.put_item")
def test_create_user_bank_fund_success(mock_audit_put, mock_put, mock_update, mock_bf_get, mock_user_get, mock_user, mock_bank_fund):
    # Mock DB responses
    mock_user_get.return_value = {"Item": mock_user}
    mock_bf_get.return_value = {"Item": mock_bank_fund}

    result, status = controller.create_user_bank_fund_controller("user-1", "bf-1")

    assert status == 201
    assert result["user_id"] == "user-1"
    assert result["bank_funds_id"] == "bf-1"
    assert mock_update.called
    assert mock_put.called
    assert mock_audit_put.called

@patch("app.controllers.user_bank_funds_audit_controller.users_db.get_item")
def test_create_user_bank_fund_user_not_found(mock_user_get):
    mock_user_get.return_value = {"Item": None}

    result, status = controller.create_user_bank_fund_controller("non-existent", "bf-1")
    assert status == 404
    assert "error" in result

@patch("app.controllers.user_bank_funds_audit_controller.users_db.get_item")
@patch("app.controllers.user_bank_funds_audit_controller.bank_funds_db.get_item")
def test_create_user_bank_fund_bank_fund_not_found(mock_bf_get, mock_user_get, mock_user):
    mock_user_get.return_value = {"Item": mock_user}
    mock_bf_get.return_value = {"Item": None}

    result, status = controller.create_user_bank_fund_controller("user-1", "bf-999")
    assert status == 404
    assert "error" in result

@patch("app.controllers.user_bank_funds_audit_controller.users_db.get_item")
@patch("app.controllers.user_bank_funds_audit_controller.bank_funds_db.get_item")
def test_create_user_bank_fund_insufficient_amount(mock_bf_get, mock_user_get):
    mock_user_get.return_value = {"Item": {"id": "user-1", "amount": "500"}}
    mock_bf_get.return_value = {"Item": {"id": "bf-1", "name": "Fondo X", "min_amount": "1000"}}

    result, status = controller.create_user_bank_fund_controller("user-1", "bf-1")
    assert status == 400
    assert "error" in result

# ================= READ =================
@patch("app.controllers.user_bank_funds_audit_controller.user_bank_funds_audit_db.get_item")
def test_get_user_bank_funds_audit_by_id(mock_get_item):
    mock_get_item.return_value = {"Item": {"id": "audit-1", "user_id": "user-1"}}
    result, status = controller.get_user_bank_funds_audit_controller("user-1", "audit-1")
    assert status == 200
    assert result["id"] == "audit-1"

@patch("app.controllers.user_bank_funds_audit_controller.user_bank_funds_audit_db.scan")
def test_get_user_bank_funds_audit_all(mock_scan):
    mock_scan.return_value = {
        "Items": [
            {"id": "audit-1", "user_id": "user-1", "created_at": "2025-01-01T12:00:00"},
            {"id": "audit-2", "user_id": "user-1", "created_at": "2025-01-02T12:00:00"},
        ]
    }

    items, status = controller.get_user_bank_funds_audit_controller("user-1")
    assert status == 200
    assert len(items) == 2
    # Verificar que se ordena descendente por created_at
    assert items[0]["created_at"] >= items[1]["created_at"]
