# tests/controllers/auth_decorators_test.py
import pytest
from unittest.mock import patch, MagicMock
from flask import Flask, jsonify
from app.controllers.auth_decorators import auth_required

# Crear app para contexto de prueba
app = Flask(__name__)

# Rutas de prueba
@app.route("/protected")
@auth_required()
def protected_route(user_id=None, role=None):
    return {"message": "Access granted"}, 200

@app.route("/admin")
@auth_required(require_admin=True)
def admin_route(user_id=None, role=None):
    return {"message": "Admin access granted"}, 200

# Mock de usuario
mock_user_attributes = [
    {"Name": "sub", "Value": "user-1"},
    {"Name": "custom:role", "Value": "user"},
]

mock_admin_attributes = [
    {"Name": "sub", "Value": "admin-1"},
    {"Name": "custom:role", "Value": "admin"},
]

# =========================
# TESTS
# =========================

@patch("app.controllers.auth_decorators.cognito_client")
def test_auth_required_invalid_token(mock_cognito):
    # Simular que get_user lanza NotAuthorizedException
    mock_cognito.get_user.side_effect = mock_cognito.exceptions.NotAuthorizedException({}, "msg")

    with app.test_request_context(
        "/protected", headers={"Authorization": "Bearer invalid", "X-Refresh-Token": "refresh123"}
    ):
        resp = protected_route()
        assert resp.status_code == 401
        assert b"Token requerido" in resp.data or b"Token invalido" in resp.data


@patch("app.controllers.auth_decorators.cognito_client")
def test_auth_required_missing_headers(mock_cognito):
    # Sin headers
    with app.test_request_context("/protected", headers={}):
        resp = protected_route()
        assert resp.status_code == 401
        assert b"Token requerido" in resp.data


@patch("app.controllers.auth_decorators.cognito_client")
def test_auth_required_admin_access_denied(mock_cognito):
    # Usuario normal
    mock_cognito.get_user.return_value = {"UserAttributes": mock_user_attributes}

    with app.test_request_context(
        "/admin", headers={"Authorization": "Bearer token123", "X-Refresh-Token": "refresh123"}
    ):
        resp = admin_route()
        assert resp.status_code == 403
        assert b"Acceso denegado" in resp.data


@patch("app.controllers.auth_decorators.cognito_client")
def test_auth_required_admin_access_granted(mock_cognito):
    # Usuario admin
    mock_cognito.get_user.return_value = {"UserAttributes": mock_admin_attributes}

    with app.test_request_context(
        "/admin", headers={"Authorization": "Bearer token123", "X-Refresh-Token": "refresh123"}
    ):
        resp = admin_route()
        assert resp.status_code == 200
        assert b"Admin access granted" in resp.data
