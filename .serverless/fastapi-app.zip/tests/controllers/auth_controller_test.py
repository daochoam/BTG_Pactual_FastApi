import pytest
from unittest.mock import patch, MagicMock
from app.controllers.auth_controller import register_user, login_user, logout_user, get_current_user
from flask import Flask

# Necesario para usar make_response en tests
app = Flask(__name__)

# -------------------------------
# TEST REGISTER_USER
# -------------------------------
@patch("app.controllers.auth_controller.cognito_client")
@patch("app.controllers.auth_controller.users_db")
@patch("app.controllers.auth_controller.get_secret_hash")
def test_register_user_success(mock_secret_hash, mock_users_db, mock_cognito):
    data = {
        "nit": "123456",
        "name": "Daniel",
        "last_name": "Ochoa",
        "email": "test@example.com",
        "phone": "+123456789",
        "password": "Secret123!",
    }

    # Mock scan para que no exista el NIT
    mock_users_db.scan.return_value = {"Items": []}

    # Mock Cognito sign_up
    mock_cognito.sign_up.return_value = {"UserSub": "abc-123"}

    # Mock secret hash
    mock_secret_hash.return_value = "hashed_secret"

    resp, status = register_user(data)

    assert status == 201
    assert resp["user_id"] == "abc-123"
    assert "User registered" in resp["message"]

@patch("app.controllers.auth_controller.users_db")
def test_register_user_existing_nit(mock_users_db):
    data = {"nit": "123", "name": "x", "last_name": "y", "email": "a@b.com", "phone": "123", "password": "pwd"}
    mock_users_db.scan.return_value = {"Items": [{"id": "1"}]}
    
    resp, status = register_user(data)
    assert status == 400
    assert "NIT already registered" in resp["error"]

# -------------------------------
# TEST LOGIN_USER
# -------------------------------
@patch("app.controllers.auth_controller.cognito_client")
@patch("app.controllers.auth_controller.get_secret_hash")
def test_login_user_success(mock_secret_hash, mock_cognito):
    data = {"email": "test@example.com", "password": "pwd"}
    mock_secret_hash.return_value = "hash"
    
    mock_cognito.initiate_auth.return_value = {
        "AuthenticationResult": {
            "AccessToken": "access123",
            "RefreshToken": "refresh123"
        }
    }
    mock_cognito.get_user.return_value = {
        "UserAttributes": [
            {"Name": "sub", "Value": "user123"},
            {"Name": "custom:role", "Value": "USER"}
        ]
    }

    with app.app_context():
        resp = login_user(data)
        assert resp.status_code == 200
        assert resp.headers["Authorization"] == "Bearer access123"
        assert resp.headers["X-Refresh-Token"] == "refresh123"

# -------------------------------
# TEST LOGOUT_USER
# -------------------------------
@patch("app.controllers.auth_controller.cognito_client")
def test_logout_user_success(mock_cognito):
    with app.test_request_context(
        "/", headers={"Authorization": "Bearer access123", "X-Refresh-Token": "refresh123"}
    ):
        resp = logout_user()
        assert resp.status_code == 200
        assert "Logout successful" in resp.get_json()["message"]

# -------------------------------
# TEST GET_CURRENT_USER
# -------------------------------
@patch("app.controllers.auth_controller.users_db")
def test_get_current_user_found(mock_users_db):
    mock_users_db.get_item.return_value = {"Item": {"id": "1", "name": "Daniel", "password": "pwd"}}
    user, status = get_current_user("1")
    assert status == 200
    assert "password" not in user

def test_get_current_user_not_found():
    with patch("app.controllers.auth_controller.users_db.get_item", return_value={}):
        user, status = get_current_user("unknown")
        assert status == 404
        assert "User not found" in user["error"]
