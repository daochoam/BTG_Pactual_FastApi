# tests/user_controller_test.py
import pytest
from unittest.mock import patch, MagicMock
import app.controllers.user_controller as controller

# Mock de usuario sin password
mock_user = {
    "id": "user-1",
    "name": "Alice",
    "amount": "1000"
}

@patch("app.controllers.user_controller.users_db")
def test_get_all_users(mock_db):
    mock_db.scan.return_value = {"Items": [mock_user.copy()]}
    
    users, status = controller.get_all_users_controller()
    
    assert status == 200
    assert isinstance(users, list)
    assert len(users) == 1
    for u in users:
        assert "password" not in u  # no debe existir
        assert u["id"] == "user-1"
        assert u["name"] == "Alice"

@patch("app.controllers.user_controller.users_db")
def test_update_user_success(mock_db):
    mock_db.get_item.return_value = {"Item": mock_user.copy()}
    mock_db.update_item = MagicMock()

    data = {"amount": "1500", "name": "Alice Updated"}
    user, status = controller.update_user_controller("user-1", data)

    assert status == 200
    assert user["amount"] == "1500"
    assert user["name"] == "Alice Updated"
    assert "password" not in user

@patch("app.controllers.user_controller.users_db")
def test_update_user_no_fields(mock_db):
    mock_db.get_item.return_value = {"Item": mock_user.copy()}
    
    resp, status = controller.update_user_controller("user-1", {})
    
    assert status == 400
    assert resp["error"] == "No valid fields to update"

@patch("app.controllers.user_controller.users_db")
def test_update_user_not_found(mock_db):
    mock_db.get_item.return_value = {}  # usuario no existe
    
    resp, status = controller.update_user_controller("nonexistent-id", {"amount": "1000"})
    
    assert status == 404
    assert resp["error"] == "User not found"
