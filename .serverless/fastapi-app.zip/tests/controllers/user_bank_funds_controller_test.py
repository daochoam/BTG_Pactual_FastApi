# tests/user_bank_funds_controller_test.py
import pytest
from unittest.mock import patch, MagicMock
from decimal import Decimal
from app.controllers import user_bank_funds_controller as controller

@pytest.fixture
def mock_user():
    return {"id": "user-1", "amount": "1500", "email": "user@test.com", "name": "Test User"}

@pytest.fixture
def mock_bank_fund():
    return {"id": "bf-1", "min_amount": "1000", "currency": "COL", "name": "Fondo X"}

@pytest.fixture
def mock_user_bank_fund_dict(mock_user, mock_bank_fund):
    return {
        "user_id": mock_user["id"],
        "bank_funds_id": mock_bank_fund["id"],
        "amount": mock_bank_fund["min_amount"],
        "currency": mock_bank_fund["currency"],
        "status": "OPEN"
    }

# ---------------- CREATE ----------------
@patch("app.controllers.user_bank_funds_controller.send_subscription_funds_email")
@patch("app.controllers.user_bank_funds_controller.user_bank_funds_audit_db.put_item")
@patch("app.controllers.user_bank_funds_controller.user_bank_funds_db.put_item")
@patch("app.controllers.user_bank_funds_controller.users_db.update_item")
@patch("app.controllers.user_bank_funds_controller.bank_funds_db.get_item")
@patch("app.controllers.user_bank_funds_controller.users_db.get_item")
def test_create_user_bank_fund_success(mock_user_get, mock_bf_get, mock_update, mock_put, mock_audit_put, mock_send_email, mock_user, mock_bank_fund):
    mock_user_get.return_value = {"Item": mock_user}
    mock_bf_get.return_value = {"Item": mock_bank_fund}

    result, status = controller.create_user_bank_fund_controller("user-1", "bf-1")

    assert status == 201
    assert result["user_id"] == "user-1"
    assert result["bank_funds_id"] == "bf-1"
    mock_update.assert_called_once()
    mock_put.assert_called_once()
    mock_audit_put.assert_called_once()
    mock_send_email.assert_called_once()

# ---------------- GET ----------------
@patch("app.controllers.user_bank_funds_controller.user_bank_funds_db.get_item")
def test_get_user_bank_fund_by_id(mock_get):
    mock_get.return_value = {"Item": {"id": "ubf-1", "user_id": "user-1"}}
    result, status = controller.get_user_bank_funds_controller("user-1", "ubf-1")
    assert status == 200
    assert result["id"] == "ubf-1"

@patch("app.controllers.user_bank_funds_controller.user_bank_funds_db.scan")
def test_get_user_bank_fund_all(mock_scan, mock_user):
    mock_scan.return_value = {"Items": [mock_user]}
    result, status = controller.get_user_bank_funds_controller("user-1")
    assert status == 200
    assert len(result) == 1
    assert result[0]["id"] == "user-1"

# ---------------- DELETE ----------------
@patch("app.controllers.user_bank_funds_controller.send_retired_funds_email")
@patch("app.controllers.user_bank_funds_controller.user_bank_funds_audit_db.put_item")
@patch("app.controllers.user_bank_funds_controller.user_bank_funds_db.update_item")
@patch("app.controllers.user_bank_funds_controller.users_db.update_item")
@patch("app.controllers.user_bank_funds_controller.users_db.get_item")
@patch("app.controllers.user_bank_funds_controller.bank_funds_db.get_item")
@patch("app.controllers.user_bank_funds_controller.user_bank_funds_db.get_item")
def test_delete_user_bank_fund_success(mock_ubf_get, mock_bf_get, mock_user_get, mock_users_update, mock_ubf_update, mock_audit_put, mock_send_email, mock_user, mock_bank_fund):
    user_bank_fund = {
        "id": "ubf-1",
        "user_id": mock_user["id"],
        "bank_funds_id": mock_bank_fund["id"],
        "status": "OPEN",
        "amount": mock_bank_fund["min_amount"],
        "currency": mock_bank_fund["currency"]
    }

    mock_ubf_get.return_value = {"Item": user_bank_fund}
    mock_bf_get.return_value = {"Item": mock_bank_fund}
    mock_user_get.return_value = {"Item": mock_user}

    result, status = controller.delete_user_bank_fund_controller("user-1", "ubf-1")

    assert status == 201
    assert result["status"] == "CLOSED"
    mock_users_update.assert_called_once()
    mock_ubf_update.assert_called_once()
    mock_audit_put.assert_called_once()
    mock_send_email.assert_called_once()
